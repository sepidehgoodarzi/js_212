module.exports=(app)=>{
    app.use((req,res,next)=>{
            req.r={
                status:true,
                data:{}
            }
            res.header("Access-Control-Allow-Origin", "*");
            res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
        next();
    })
}



