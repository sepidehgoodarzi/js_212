const mongoose = require('mongoose');
const mongodb = require ('mongodb');
let url ="mongodb://127.0.0.1:27017/js-212"
let db = mongoose.connect(url,{ useNewUrlParser: true });

module.exports=db;