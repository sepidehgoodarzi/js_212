const mongoose=require('mongoose');
let answerSchema= new mongoose.Schema({

        questionID  : {type:String},
        userID      : {type:String},
        userAnswer  : {type:String},
        dateAnser   : {type:String},
        answerID    : {type:String}
},{
    collection:'answer'
})
module.exports = mongoose.model('answerSchema',answerSchema)

