const mongoose = require ('mongoose');

let qSchema =new mongoose.Schema({

        qID     :{type :String},
        qTitle      : {type:String},
        qType       : { type:String },
        qParentID   : { type:String },
        qContent    : {type : Array},

    },
    {
        collection:'question'
    }
);
module.exports =mongoose.model('qSchema',qSchema)
