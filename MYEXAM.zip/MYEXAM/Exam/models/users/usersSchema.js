const mongoose =require('mongoose');

let userSchema = new mongoose.Schema({
        userID      :{type:String},
        name        :{type:String},
        family     :{type:String},
        psw         :{type:String},
        userName    :{type:String}
        },
        {
            collection:'user',
        }
);
module.exports =mongoose.model('userSchema',userSchema);