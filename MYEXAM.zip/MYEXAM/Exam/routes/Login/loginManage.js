const express = require ('express');
const router = express.Router();
let userSchema = require('../../models/users/usersSchema');


//********************************Check Login
router.get('/:LoginInfo',(req,res,next)=>{
    var qLogin = req.params.LoginInfo;

    var uname =  qLogin.split("-")[0];
    var psw =  qLogin.split("-")[1];
    userSchema.find({ 'userName': uname, 'psw' : psw }, 'userID name family psw userName').exec().then(
        (user)=>{
            res.json(
                Object.assign(req.r,{
                    data:user
                })
            )
        }
    )
        .catch(
            (e)=>{
                res.json(req.r,{
                    success: false,
                    msg:"failed"
                })
            }
        )
})


module.exports=router;