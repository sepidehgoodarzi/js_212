const express = require ('express');
const router = express.Router();
let answerSchema = require('../../models/answer/answerSchema');
let qSchema= require('../../models/questions/questionSchema');
//********************************POST
router.post('/',(req, res, next)=>{
     let answer = new answerSchema;
         answer.questionID =req.body.questionID;
         answer.userID =req.body.userID;
         answer.userAnswer =req.body.userAnswer;
         answer.dateAnser =req.body.dateAnser;
         answer.answerID =req.body.answerID;

    answer.save().then(
        ()=>{
            res.json(
                Object.assign(req.r,{
                    data:answer
                })
            )
        }
    ).catch(
        (e)=>{
            res.json(req.r,{
                    success: false,
                    msg:"failed"
                }
            )
        }
    )
});
//********************************GET
router.get('/',(req,res,next)=>{
    answerSchema.find().exec().then(
            (answers)=>{
                res.json(
                    Object.assign(req.r,{
                        data:answers
                    })
                )
            }
        )
        .catch(
        (e)=>{
            res.json(req.r,{
                success: false,
                msg:"failed"
            })
        }
    )
})
//********************************GETBYID
router.get('/:Id',(req,res,next)=>{
    answerSchema.findById(req.params.Id).exec().then(
        (answers)=>{
            res.json(
                Object.assign(req.r,{
                    data:[answers]
                })
            );
        }
    ).catch(
        (e)=>{
            res.json(req.r,{
                success: false,
                msg:"failed"
            })
        }
    )
})

//********************************PUT
router.put('/:Id',(req,res,next)=>{
    answerSchema.findByIdAndUpdate(req.params.Id, req.body).exec().then(
        (answer)=>{
            res.json(
                Object.assign(req.r,{
                    data:[req.body]
                })
            )
        }
    ).catch(
        (e)=>{
            res.json(req.r,{
                success: false,
                msg:"failed"
            })
        }
    )
})
//********************************DELETE
router.delete('/:Id',(req,res,next)=>{
    answerSchema.findByIdAndRemove(req.params.Id, req.body).exec().then(
        (answer)=>{
            res.json(
                Object.assign(req.r,{
                    data:[answer]
                })
            )
        }
    ).catch(
        (e)=>{
            res.json(req.r,{
                success: false,
                msg:"failed"
            })
        }
    )
})
module.exports=router;