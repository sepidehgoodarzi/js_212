module.exports=(app)=>{

    app.get('/ping',(req,res,next)=>{
        res.send("pong");
    });
    app.use('/api/user',require('./users/usersData'));
    app.use('/api/answer',require('./anwers/answerData'));
    app.use('/api/questions',require('./questions/questionData'));
    app.use('/api/query',require('./queries/answerManage'));
    app.use('/api/login',require('./Login/loginManage'));
    app.use('/api/profile',require('./userProfile/userProfile'));
    app.use('/upload',require('./upload/upload'));

}



