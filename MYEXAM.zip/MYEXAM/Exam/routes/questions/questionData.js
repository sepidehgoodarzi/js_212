const express = require ('express');
const router = express.Router();
let qSchema= require('../../models/questions/questionSchema');
//********************************POST
router.post('/',(req,res,next)=>{
let qusetion= new qSchema;
    qusetion.qID=req.body.qID;
    qusetion.qTitle=req.body.qTitle;
    qusetion.qType=req.body.qType;
    qusetion.qParentID=req.body.qParentID;
    qusetion.qContent=req.body.qContent;
    qusetion.save().then(
           ()=>{
               res.json(
                   Object.assign(req.r,{
                       data:qusetion
                   })
               )
           }
       ).catch(
           (e)=>{
               res.json(req.r,{
                       success: false,
                       msg:"failed"
                   }
               )
           }
       )
})
//********************************GET
router.get('/',(req, res, next)=>{
 qSchema.find().exec().then(
     (question)=>{
             res.json(
                 Object.assign(req.r, {
                     data: question
                 })
             )
     }
 ).catch(
     (e)=>{
         res.json(req.r,{
                success: false,
                 msg:"failed"
         }
         )
     }
 )
})
//********************************GETBYID
router.get('/:Id',(req,res,next)=>{
    qSchema.findById(req.params.Id).exec().then(
        (question)=>{
                    res.json(
                        Object.assign(req.r,{
                            data:question,

                        }
                        )
                    )
        }
    ).catch(
        (e)=>{
            res.json(req.r,{
                    success: false,
                    msg:"failed"
                }
            )
        }
    )
})
//********************************PUT
router.put('/:Id',(req,res,next)=>{
    qSchema.findByIdAndUpdate(req.params.Id,req.body).exec().then(
        (question)=>{
            res.json(
                Object.assign(req.r,{
                    data:req.body
                })
            )

        }
    ).catch(
        (e)=>{
            res.json(req.r,{
                    success: false,
                    msg:"failed"
                }
            )
        }
    )
})
//********************************DELETE
router.delete('/:Id',(req,res,next)=>{
    qSchema.findByIdAndRemove(req.params.Id,req.body).exec().then(
        (question)=>{
            res.json(
                Object.assign(req.r,{
                    data:req.body
                })
            )

        }
    ).catch(
        (e)=>{
            res.json(req.r,{
                    success: false,
                    msg:"failed"
                }
            )
        }
    )
})
module.exports=router;
