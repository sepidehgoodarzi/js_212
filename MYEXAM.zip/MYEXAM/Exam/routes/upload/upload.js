const express = require('express');
const app= express.Router();
const multer = require('multer');
const redirect = require("express-redirect");
const upload = multer({
    dest: 'C://Users//SONY//Desktop//lottary' // this saves your file into a directory called "uploads"
});

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/uploadFrom.html');
});

// It's very crucial that the file name matches the name attribute in your html
app.post('/', upload.single('file-to-upload'), (req, res,next) => {
    console.log("mannnnnnnnnnnnnnnnnnnnnnnnnnnn");
    res.redirect('https://www.google.com/');
    next();
});
module.exports=app;