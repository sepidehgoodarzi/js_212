const express = require ('express');
const router = express.Router();
let answerSchema = require('../../models/answer/answerSchema');


//********************************Get All Answer by UserID
router.get('/:userID',(req,res,next)=>{
    var userID = req.params.userID;
    answerSchema.find({ 'userID': userID }, 'questionID userID userAnswer dateAnser answerID').exec().then(
        (qs)=>{
            res.json(
                Object.assign(req.r,{
                    data:qs
                })
            )
        }
    )
        .catch(
            (e)=>{
                res.json(req.r,{
                    success: false,
                    msg:"failed"
                })
            }
        )
})


module.exports=router;