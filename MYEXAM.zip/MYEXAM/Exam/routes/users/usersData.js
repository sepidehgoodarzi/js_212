const express = require('express');
const router=express.Router();
let user = require('../../models/users/usersSchema');
//********************************GET
router.get('/',(req,res,next)=>{
    console.log(req.r);
    user.find().exec().then(
         (user)=>{
             res.json(
                 Object.assign(req.r,{
                    data:[user]
                 })
             );
         }
     ).catch(
        (e)=>{
            res.json(
                Object.assign(req.r,{
                    success:false,
                    msg:"failed"
                })
            )
        }
    )
})
//********************************GETBYID
router.get('/:Id',(req,res,next)=>{
    user.findById(req.params.Id).exec().then(
        (user)=>{
            res.json(
                Object.assign(req.r,{
                    data:[user]
                })
            );
        }
    ).catch(
        (e)=>{
            res.json(req.r,{
                success: false,
                msg:"failed"
            })
        }
    )
})
//********************************POST
router.post('/',(req, res, nest)=>{
    let users = new user;
    users.userID = req.body.userID;
    users.name =req.body.name;
    users.family =req.body.family;
    users.psw = req.body.psw;
    users.userName = req.body.userName;

    console.log(req.body)


    users.save().then(
        ()=>{
            res.json(
                Object.assign(req.r,{
                    data:[req.body]
                })
            );
        }
    ).catch(
        (e)=>{
            res.json(req.r,{
                success: false,
                msg:"failed"
            })
        }
    )
});
//********************************PUT
router.put('/:Id',(req,res,next)=>{
    user.findByIdAndUpdate(req.params.Id, req.body).exec().then(
        (user)=>{
            res.json(
                Object.assign(req.r,{
                    data:[req.body]
                })
            )
        }
    ).catch(
        (e)=>{
            res.json(req.r,{
                success: false,
                msg:"failed"
            })
        }
    )
})
//********************************DELETE
router.delete('/:Id',(req,res,next)=>{
    user.findByIdAndRemove(req.params.Id, req.body).exec().then(
        (user)=>{
            res.json(
                Object.assign(req.r,{
                    data:[user]
                })
            )
        }
    ).catch(
        (e)=>{
            res.json(req.r,{
                success: false,
                msg:"failed"
            })
        }
    )
})
module.exports=router;
